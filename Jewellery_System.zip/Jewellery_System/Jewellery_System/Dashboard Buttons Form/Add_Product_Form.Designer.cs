﻿
namespace Jewellery_System
{
    partial class Add_Product_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.btnSaveproduct = new Guna.UI2.WinForms.Guna2Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtboxdescription = new System.Windows.Forms.TextBox();
            this.cmbproducttype = new Guna.UI2.WinForms.Guna2ComboBox();
            this.txtboxnoofstock = new System.Windows.Forms.TextBox();
            this.labelOrderDate = new System.Windows.Forms.Label();
            this.txtboxModelNo = new System.Windows.Forms.TextBox();
            this.labelContactNumber = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtproductPrice = new System.Windows.Forms.TextBox();
            this.labelOrderID = new System.Windows.Forms.Label();
            this.txtboxProductName = new System.Windows.Forms.TextBox();
            this.labelCustomerName = new System.Windows.Forms.Label();
            this.labelContactus = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.btnSaveproduct);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.txtboxdescription);
            this.panel1.Controls.Add(this.cmbproducttype);
            this.panel1.Controls.Add(this.txtboxnoofstock);
            this.panel1.Controls.Add(this.labelOrderDate);
            this.panel1.Controls.Add(this.txtboxModelNo);
            this.panel1.Controls.Add(this.labelContactNumber);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.txtproductPrice);
            this.panel1.Controls.Add(this.labelOrderID);
            this.panel1.Controls.Add(this.txtboxProductName);
            this.panel1.Controls.Add(this.labelCustomerName);
            this.panel1.Controls.Add(this.labelContactus);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(760, 537);
            this.panel1.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Californian FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(86, 393);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(20, 22);
            this.label1.TabIndex = 51;
            this.label1.Text = "*";
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Californian FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Red;
            this.label13.Location = new System.Drawing.Point(146, 206);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(20, 22);
            this.label13.TabIndex = 50;
            this.label13.Text = "*";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Californian FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(107, 83);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(20, 22);
            this.label5.TabIndex = 28;
            this.label5.Text = "*";
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Californian FB", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Location = new System.Drawing.Point(727, 5);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(28, 27);
            this.label12.TabIndex = 49;
            this.label12.Text = "X";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // btnSaveproduct
            // 
            this.btnSaveproduct.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnSaveproduct.BorderRadius = 5;
            this.btnSaveproduct.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnSaveproduct.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnSaveproduct.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnSaveproduct.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnSaveproduct.FillColor = System.Drawing.Color.RosyBrown;
            this.btnSaveproduct.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.btnSaveproduct.ForeColor = System.Drawing.Color.White;
            this.btnSaveproduct.Location = new System.Drawing.Point(8, 493);
            this.btnSaveproduct.Name = "btnSaveproduct";
            this.btnSaveproduct.Size = new System.Drawing.Size(148, 33);
            this.btnSaveproduct.TabIndex = 48;
            this.btnSaveproduct.Text = "Save Product";
            this.btnSaveproduct.Click += new System.EventHandler(this.btnSaveproduct_Click);
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Californian FB", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label9.Location = new System.Drawing.Point(5, 393);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(85, 18);
            this.label9.TabIndex = 44;
            this.label9.Text = "Description";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Californian FB", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label8.Location = new System.Drawing.Point(6, 206);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(143, 18);
            this.label8.TabIndex = 43;
            this.label8.Text = "Select Product Type";
            // 
            // txtboxdescription
            // 
            this.txtboxdescription.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtboxdescription.Location = new System.Drawing.Point(9, 417);
            this.txtboxdescription.Multiline = true;
            this.txtboxdescription.Name = "txtboxdescription";
            this.txtboxdescription.Size = new System.Drawing.Size(665, 70);
            this.txtboxdescription.TabIndex = 41;
            // 
            // cmbproducttype
            // 
            this.cmbproducttype.BackColor = System.Drawing.Color.Transparent;
            this.cmbproducttype.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbproducttype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbproducttype.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbproducttype.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbproducttype.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cmbproducttype.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cmbproducttype.ItemHeight = 30;
            this.cmbproducttype.Location = new System.Drawing.Point(10, 229);
            this.cmbproducttype.Name = "cmbproducttype";
            this.cmbproducttype.Size = new System.Drawing.Size(329, 36);
            this.cmbproducttype.TabIndex = 40;
            // 
            // txtboxnoofstock
            // 
            this.txtboxnoofstock.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtboxnoofstock.Location = new System.Drawing.Point(9, 353);
            this.txtboxnoofstock.Multiline = true;
            this.txtboxnoofstock.Name = "txtboxnoofstock";
            this.txtboxnoofstock.Size = new System.Drawing.Size(665, 30);
            this.txtboxnoofstock.TabIndex = 36;
            // 
            // labelOrderDate
            // 
            this.labelOrderDate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelOrderDate.AutoSize = true;
            this.labelOrderDate.Font = new System.Drawing.Font("Californian FB", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelOrderDate.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.labelOrderDate.Location = new System.Drawing.Point(7, 144);
            this.labelOrderDate.Name = "labelOrderDate";
            this.labelOrderDate.Size = new System.Drawing.Size(76, 18);
            this.labelOrderDate.TabIndex = 31;
            this.labelOrderDate.Text = "Model No.";
            // 
            // txtboxModelNo
            // 
            this.txtboxModelNo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtboxModelNo.Location = new System.Drawing.Point(9, 168);
            this.txtboxModelNo.Multiline = true;
            this.txtboxModelNo.Name = "txtboxModelNo";
            this.txtboxModelNo.Size = new System.Drawing.Size(664, 30);
            this.txtboxModelNo.TabIndex = 33;
            // 
            // labelContactNumber
            // 
            this.labelContactNumber.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelContactNumber.AutoSize = true;
            this.labelContactNumber.Font = new System.Drawing.Font("Californian FB", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelContactNumber.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.labelContactNumber.Location = new System.Drawing.Point(9, 332);
            this.labelContactNumber.Name = "labelContactNumber";
            this.labelContactNumber.Size = new System.Drawing.Size(91, 18);
            this.labelContactNumber.TabIndex = 32;
            this.labelContactNumber.Text = "No. of Stock";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Californian FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(78, 144);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(20, 22);
            this.label4.TabIndex = 34;
            this.label4.Text = "*";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Californian FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(96, 329);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(20, 22);
            this.label7.TabIndex = 35;
            this.label7.Text = "*";
            // 
            // txtproductPrice
            // 
            this.txtproductPrice.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtproductPrice.Location = new System.Drawing.Point(9, 296);
            this.txtproductPrice.Multiline = true;
            this.txtproductPrice.Name = "txtproductPrice";
            this.txtproductPrice.Size = new System.Drawing.Size(665, 30);
            this.txtproductPrice.TabIndex = 30;
            // 
            // labelOrderID
            // 
            this.labelOrderID.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelOrderID.AutoSize = true;
            this.labelOrderID.Font = new System.Drawing.Font("Californian FB", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelOrderID.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.labelOrderID.Location = new System.Drawing.Point(9, 83);
            this.labelOrderID.Name = "labelOrderID";
            this.labelOrderID.Size = new System.Drawing.Size(102, 18);
            this.labelOrderID.TabIndex = 25;
            this.labelOrderID.Text = "Product Name";
            // 
            // txtboxProductName
            // 
            this.txtboxProductName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtboxProductName.Location = new System.Drawing.Point(9, 107);
            this.txtboxProductName.Multiline = true;
            this.txtboxProductName.Name = "txtboxProductName";
            this.txtboxProductName.Size = new System.Drawing.Size(665, 30);
            this.txtboxProductName.TabIndex = 27;
            // 
            // labelCustomerName
            // 
            this.labelCustomerName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelCustomerName.AutoSize = true;
            this.labelCustomerName.Font = new System.Drawing.Font("Californian FB", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCustomerName.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.labelCustomerName.Location = new System.Drawing.Point(8, 272);
            this.labelCustomerName.Name = "labelCustomerName";
            this.labelCustomerName.Size = new System.Drawing.Size(99, 18);
            this.labelCustomerName.TabIndex = 26;
            this.labelCustomerName.Text = "Product Price";
            // 
            // labelContactus
            // 
            this.labelContactus.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelContactus.AutoSize = true;
            this.labelContactus.Font = new System.Drawing.Font("Californian FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelContactus.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.labelContactus.Location = new System.Drawing.Point(7, 25);
            this.labelContactus.Name = "labelContactus";
            this.labelContactus.Size = new System.Drawing.Size(107, 22);
            this.labelContactus.TabIndex = 23;
            this.labelContactus.Text = "Add Product";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label2.Location = new System.Drawing.Point(8, 47);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(736, 16);
            this.label2.TabIndex = 24;
            this.label2.Text = "_________________________________________________________________________________" +
    "__________";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Californian FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(103, 272);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(20, 22);
            this.label6.TabIndex = 29;
            this.label6.Text = "*";
            // 
            // Add_Product_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.RosyBrown;
            this.ClientSize = new System.Drawing.Size(766, 543);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Add_Product_Form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add_Product_Form";
            this.Load += new System.EventHandler(this.Add_Product_Form_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label12;
        private Guna.UI2.WinForms.Guna2Button btnSaveproduct;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtboxdescription;
        private Guna.UI2.WinForms.Guna2ComboBox cmbproducttype;
        private System.Windows.Forms.TextBox txtboxnoofstock;
        private System.Windows.Forms.Label labelOrderDate;
        private System.Windows.Forms.TextBox txtboxModelNo;
        private System.Windows.Forms.Label labelContactNumber;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtproductPrice;
        private System.Windows.Forms.Label labelOrderID;
        private System.Windows.Forms.TextBox txtboxProductName;
        private System.Windows.Forms.Label labelCustomerName;
        private System.Windows.Forms.Label labelContactus;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
    }
}