﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hostel_Management_System
{

    public enum MenuObject
    {
        None = 0,
        Room = 1,

    }

    
    
    internal static class GeneralFunction
    {
        internal static Form mdiForm = null;
    }

  

}
